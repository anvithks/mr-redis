# VNF Marketplace.

A GUI to a access and manage the VNF Marketplace.



## Getting started

Clone project:

    $ git clone https://github.com/

Install dependencies:

    $ cd vnfmarketplace
    $ npm install

Run development web-server:

    $ grunt dev

## Features

* List features here

## Project structure and credits

* Project credits here
