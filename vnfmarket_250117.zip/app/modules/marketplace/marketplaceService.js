(function() {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.service:marketplaceService
	 * @description
	 * # marketplaceService
	 * Service of the app
	 */

  	angular
		.module('marketplace')
		.factory('MarketplaceService', Marketplace);
		// Inject your dependencies as .$inject = ['$http', 'someSevide'];
		// function Name ($http, someSevide) {...}

		Marketplace.$inject = ['$http'];

		function Marketplace ($http) {

		}

})();
