(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.test:marketplaceTest
	 * @description
	 * # marketplaceTest
	 * Test of the app
	 */

	describe('marketplace test', function () {
		var controller = null, $scope = null;

		beforeEach(function () {
			module('vnfmarket');
		});

		beforeEach(inject(function ($controller, $rootScope) {
			$scope = $rootScope.$new();
			controller = $controller('MarketplaceCtrl', {
				$scope: $scope
			});
		}));

		it('Should controller must be defined', function () {
			expect(controller).toBeDefined();
		});

	});
})();
