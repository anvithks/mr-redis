(function() {
	'use strict';

	/**
	* @ngdoc function
	* @name app.controller:marketplaceCtrl
	* @description
	* # marketplaceCtrl
	* Controller of the app
	*/

  	angular
		.module('marketplace')
		.controller('MarketplaceCtrl', Marketplace);

		Marketplace.$inject = [];

		/*
		* recommend
		* Using function declarations
		* and bindable members up top.
		*/

		function Marketplace() {
			/*jshint validthis: true */
			var vm = this;

		}

})();
