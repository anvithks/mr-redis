(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:marketplaceModule
	 * @description
	 * # marketplaceModule
	 * Module of the app
	 */

  	angular.module('marketplace', []);

})();
