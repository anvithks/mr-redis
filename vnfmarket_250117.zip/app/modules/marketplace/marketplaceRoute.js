'use strict';

/**
 * @ngdoc function
 * @name app.route:marketplaceRoute
 * @description
 * # marketplaceRoute
 * Route of the app
 */

angular.module('marketplace')
	.config(['$stateProvider', function ($stateProvider) {

		$stateProvider
			.state('home.marketplace', {
				url:'/marketplace',
				templateUrl: 'app/modules/marketplace/marketplace.html',
				controller: 'MarketplaceCtrl',
				controllerAs: 'vm'
			});


	}]);
