(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:aboutModule
	 * @description
	 * # aboutModule
	 * Module of the app
	 */

  	angular.module('about', []);

})();
