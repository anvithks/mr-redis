'use strict';

/**
 * @ngdoc function
 * @name app.route:aboutRoute
 * @description
 * # aboutRoute
 * Route of the app
 */

angular.module('about')
	.config(['$stateProvider', function ($stateProvider) {

		$stateProvider
			.state('home.about', {
				url:'/about',
				templateUrl: 'app/modules/about/about.html',
				controller: 'AboutCtrl',
				controllerAs: 'vm'
			});


	}]);
