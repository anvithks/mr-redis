(function() {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.service:aboutService
	 * @description
	 * # aboutService
	 * Service of the app
	 */

  	angular
		.module('about')
		.factory('AboutService', About);
		// Inject your dependencies as .$inject = ['$http', 'someSevide'];
		// function Name ($http, someSevide) {...}

		About.$inject = ['$http'];

		function About ($http) {

		}

})();
