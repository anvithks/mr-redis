(function() {
	'use strict';

	/**
	* @ngdoc function
	* @name app.controller:aboutCtrl
	* @description
	* # aboutCtrl
	* Controller of the app
	*/

  	angular
		.module('about')
		.controller('AboutCtrl', About);

		About.$inject = [];

		/*
		* recommend
		* Using function declarations
		* and bindable members up top.
		*/

		function About() {
			/*jshint validthis: true */
			var vm = this;

		}

})();
