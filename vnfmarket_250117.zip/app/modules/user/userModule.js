(function () {
	'use strict';

	/**
	 * @ngdoc function
	 * @name app.module:userModule
	 * @description
	 * # userModule
	 * Module of the app
	 */

  	angular.module('user', []);

})();
